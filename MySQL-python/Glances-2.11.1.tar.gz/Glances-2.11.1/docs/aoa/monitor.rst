.. _monitor:

Monitored Processes List
========================

.. warning::
    The monitored processes list feature has been removed. Use the new
    Application Monitoring Process (AMP) instead.
