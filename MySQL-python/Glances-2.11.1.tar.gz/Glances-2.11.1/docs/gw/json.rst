.. _json:

JSON
====

It's possible to export stats to a JSON file.

.. code-block:: console

    $ glances --export-json /tmp/glances.json
