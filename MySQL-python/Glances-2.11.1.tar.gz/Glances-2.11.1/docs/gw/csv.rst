.. _csv:

CSV
===

It's possible to export stats to a CSV file.

.. code-block:: console

    $ glances --export-csv /tmp/glances.csv

CSV file description:

- Stats description (first line)
- Stats (other lines)
