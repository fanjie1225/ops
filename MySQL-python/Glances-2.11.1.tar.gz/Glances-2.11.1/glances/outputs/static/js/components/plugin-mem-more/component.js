'use strict';

glancesApp.component('glancesPluginMemMore', {
    controller: GlancesPluginMemMoreController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-mem-more/view.html'
});
