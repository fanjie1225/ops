'use strict';

glancesApp.component('glancesPluginIp', {
    controller: GlancesPluginIpController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-ip/view.html'
});
