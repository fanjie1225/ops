'use strict';

glancesApp.component('glancesPluginWifi', {
    controller: GlancesPluginWifiController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-wifi/view.html'
});
