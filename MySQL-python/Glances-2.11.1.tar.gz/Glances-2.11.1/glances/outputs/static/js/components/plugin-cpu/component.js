'use strict';

glancesApp.component('glancesPluginCpu', {
    controller: GlancesPluginCpuController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-cpu/view.html'
});
