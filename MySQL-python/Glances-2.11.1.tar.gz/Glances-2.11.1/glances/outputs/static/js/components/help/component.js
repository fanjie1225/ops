'use strict';

glancesApp.component('glancesHelp', {
    controller: GlancesHelpController,
    controllerAs: 'vm',
    templateUrl: 'components/help/view.html'
});
