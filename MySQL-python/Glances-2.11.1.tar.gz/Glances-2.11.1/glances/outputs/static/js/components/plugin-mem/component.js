'use strict';

glancesApp.component('glancesPluginMem', {
    controller: GlancesPluginMemController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-mem/view.html'
});
