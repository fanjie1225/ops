'use strict';

glancesApp.component('glancesPluginQuicklook', {
    controller: GlancesPluginQuicklookController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-quicklook/view.html'
});
