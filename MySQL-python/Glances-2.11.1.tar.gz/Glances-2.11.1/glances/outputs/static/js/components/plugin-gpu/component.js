'use strict';

glancesApp.component('glancesPluginGpu', {
    controller: GlancesPluginGpuController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-gpu/view.html'
});
