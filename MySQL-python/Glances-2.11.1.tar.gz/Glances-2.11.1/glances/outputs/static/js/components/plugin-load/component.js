'use strict';

glancesApp.component('glancesPluginLoad', {
    controller: GlancesPluginLoadController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-load/view.html'
});
