'use strict';

glancesApp.component('glancesPluginRaid', {
    controller: GlancesPluginRaidController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-raid/view.html'
});
