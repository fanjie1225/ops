'use strict';

glancesApp.component('glancesPluginDocker', {
    controller: GlancesPluginDockerController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-docker/view.html'
});
