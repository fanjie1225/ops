'use strict';

glancesApp.component('glancesPluginCloud', {
    controller: GlancesPluginCloudController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-cloud/view.html'
});
