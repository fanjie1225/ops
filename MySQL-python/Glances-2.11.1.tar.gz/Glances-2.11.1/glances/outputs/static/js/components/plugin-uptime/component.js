'use strict';

glancesApp.component('glancesPluginUptime', {
    controller: GlancesPluginUptimeController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-uptime/view.html'
});
