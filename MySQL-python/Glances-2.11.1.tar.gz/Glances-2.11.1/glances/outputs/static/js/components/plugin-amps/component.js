'use strict';

glancesApp.component('glancesPluginAmps', {
    controller: GlancesPluginAmpsController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-amps/view.html'
});
