'use strict';

glancesApp.component('glancesPluginNetwork', {
    controller: GlancesPluginNetworkController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-network/view.html'
});
