'use strict';

glancesApp.component('glancesPluginFolders', {
    controller: GlancesPluginFsController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-folders/view.html'
});
