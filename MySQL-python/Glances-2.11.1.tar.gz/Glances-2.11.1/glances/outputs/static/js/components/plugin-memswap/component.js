'use strict';

glancesApp.component('glancesPluginMemswap', {
    controller: GlancesPluginMemswapController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-memswap/view.html'
});
