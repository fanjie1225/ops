'use strict';

glancesApp.component('glancesPluginSensors', {
    controller: GlancesPluginSensorsController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-sensors/view.html'
});
