'use strict';

glancesApp.component('glancesPluginAlert', {
    controller: GlancesPluginAlertController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-alert/view.html'
});
