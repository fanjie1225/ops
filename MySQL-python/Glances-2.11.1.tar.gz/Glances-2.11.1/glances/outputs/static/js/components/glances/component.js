'use strict';

glancesApp.component('glances', {
    controller: GlancesController,
    controllerAs: 'vm',
    templateUrl: 'components/glances/view.html'
});
