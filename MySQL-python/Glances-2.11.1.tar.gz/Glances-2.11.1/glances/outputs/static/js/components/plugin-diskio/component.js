'use strict';

glancesApp.component('glancesPluginDiskio', {
    controller: GlancesPluginDiskioController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-diskio/view.html'
});
