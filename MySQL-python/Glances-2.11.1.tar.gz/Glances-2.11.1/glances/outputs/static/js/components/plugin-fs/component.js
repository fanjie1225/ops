'use strict';

glancesApp.component('glancesPluginFs', {
    controller: GlancesPluginFsController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-fs/view.html'
});
