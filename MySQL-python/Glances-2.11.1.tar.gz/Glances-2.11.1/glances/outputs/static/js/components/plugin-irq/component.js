'use strict';

glancesApp.component('glancesPluginIrq', {
    controller: GlancesPluginIrqController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-irq/view.html'
});
