'use strict';

glancesApp.component('glancesPluginPercpu', {
    controller: GlancesPluginPercpuController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-percpu/view.html'
});
