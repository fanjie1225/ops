'use strict';

glancesApp.component('glancesPluginPorts', {
    controller: GlancesPluginPortsController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-ports/view.html'
});
