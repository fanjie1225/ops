'use strict';

glancesApp.component('glancesPluginSystem', {
    controller: GlancesPluginSystemController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-system/view.html'
});
