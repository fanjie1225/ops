'use strict';

glancesApp.component('glancesPluginProcess', {
    controller: GlancesPluginProcessController,
    controllerAs: 'vm',
    templateUrl: 'components/plugin-process/view.html'
});
